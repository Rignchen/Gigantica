
- Gigantica - Datapack Jam 9

- The Gigantica datapack features a new overgrown custom plant boss that spawns by using a bonemeal essence on a carnivorous plant. This rare plant can be found in abandoned underground labs scattered across the plains biome. These labs were once owned by the (now deceased) plains village scientist who worked tirelessly to bring new overgrowth to the overworld, but failed to contain the deadly Gigantica plant.

- Datapack Features:

    - Gigantica: The overgrown carnivorous plant. This new boss is a stationary plant that targets the player by using poisonous spikes and bubbles, and will also attack players with a wither effect if they come too close. The Gigantica plant is also able to regenerate its health if it comes into contact with water.
    - Bonemeal Essence: A distilled version of bonemeal that acts like a super-fertilizer for certain plants. Use on carrots, wheat, potatoes, or beetroot to grow them into super crops that yield more when harvested. It can also be used on a carnivorous plant to summon the Gigantica boss.
    - Crops Spread: Crops (carrots, wheat, potatoes, and beetroot) that are placed by the player, and are fully grown, now spread to adjacent blocks at random.
    - Overworld Crops: Crops (carrots, wheat, potatoes, and beetroot) generate more abundantly across many different biomes in the Overworld.
